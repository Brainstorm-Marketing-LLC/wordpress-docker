<?php
/**
 * WPSEO plugin file.
 *
 * @package WPSEO\Internals
 */

/**
 * Class WPSEO_MyYoast_Bad_Request_Exception.
 */
class WPSEO_MyYoast_Bad_Request_Exception extends Exception {

}
